proot
=====
[![Travis build status](https://travis-ci.org/termux/proot.svg?branch=master)](https://travis-ci.org/termux/proot)

This is a copy of [the PRoot next branch](https://github.com/proot-me/PRoot/tree/next) with patches applied to work better under [Termux](https://termux.com).
