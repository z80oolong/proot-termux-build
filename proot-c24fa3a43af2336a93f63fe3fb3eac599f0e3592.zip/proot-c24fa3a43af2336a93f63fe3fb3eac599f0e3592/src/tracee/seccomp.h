#include "tracee/tracee.h"

int handle_seccomp_event(Tracee* tracee);
